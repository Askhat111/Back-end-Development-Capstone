"""Band pages and authenticated concert attendance."""
from django.conf import settings
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction
from django.http import HttpResponseBadRequest
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST
import requests
from concert.forms import LoginForm, SignUpForm
from concert.models import Concert, ConcertAttending


def signup(request):
    form = SignUpForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        username, password = form.cleaned_data["username"], form.cleaned_data["password"]
        try:
            validate_password(password, User(username=username))
            with transaction.atomic():
                user = User.objects.create_user(username=username, password=password)
        except ValidationError as exc:
            form.add_error("password", exc)
        except IntegrityError:
            form.add_error("username", "User already exists")
        else:
            login(request, user)
            return redirect("index")
    return render(request, "signup.html", {"form": form})


def index(request):
    return render(request, "index.html")


def service_data(url, fallback):
    """Lab sample until services are configured; actual outages are reported."""
    if not url:
        return fallback
    response = requests.get(url, timeout=5)
    response.raise_for_status()
    data = response.json()
    if not isinstance(data, list):
        raise ValueError("Expected a JSON list")
    return data


def songs(request):
    sample = [{"id": 1, "title": "Sample Song", "lyrics": "Sample lyrics"}]
    try:
        data = service_data(settings.SONGS_API_URL, sample)
    except (requests.RequestException, ValueError):
        return render(request, "songs.html", {"songs": [], "service_error": True}, status=503)
    return render(request, "songs.html", {"songs": data})


def photos(request):
    sample = [{"id": 1, "pic_url": "https://dummyimage.com/136x100.png/5fa2dd/ffffff",
               "event_country": "United States", "event_state": "District of Columbia",
               "event_city": "Washington", "event_date": "11/16/2022"}]
    try:
        data = service_data(settings.PICTURES_API_URL, sample)
    except (requests.RequestException, ValueError):
        return render(request, "photos.html", {"photos": [], "service_error": True}, status=503)
    return render(request, "photos.html", {"photos": data})


def login_view(request):
    form = LoginForm(request, data=request.POST or None)
    if request.method == "POST" and form.is_valid():
        login(request, form.get_user())
        return redirect("index")
    return render(request, "login.html", {"form": form})


def logout_view(request):
    logout(request)
    return redirect("login")


@login_required(login_url="login")
def concerts(request):
    statuses = dict(ConcertAttending.objects.filter(user=request.user).values_list("concert_id", "attending"))
    data = [{"concert": item, "status": statuses.get(item.pk, "-")} for item in Concert.objects.all()]
    return render(request, "concerts.html", {"concerts": data})


@login_required(login_url="login")
def concert_detail(request, id):
    obj = get_object_or_404(Concert, pk=id)
    entry = obj.attendee.filter(user=request.user).first()
    return render(request, "concert_detail.html", {
        "concert_details": obj, "status": entry.attending if entry else "-",
        "attending_choices": ConcertAttending.AttendingChoices.choices})


@login_required(login_url="login")
@require_POST
def concert_attendee(request):
    status = request.POST.get("attendee_choice")
    if status not in ConcertAttending.AttendingChoices.values:
        return HttpResponseBadRequest("Invalid attendance choice")
    concert = get_object_or_404(Concert, pk=request.POST.get("concert_id"))
    ConcertAttending.objects.update_or_create(concert=concert, user=request.user, defaults={"attending": status})
    return redirect("concerts")
