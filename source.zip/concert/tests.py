from unittest.mock import patch, Mock
from django.contrib.auth.models import User
from django.contrib import admin
from django.test import TestCase, override_settings
from django.urls import reverse
from .models import Concert, ConcertAttending


class BandFlowTests(TestCase):
    def setUp(self):
        self.concert = Concert.objects.create(concert_name="Autumn Live", duration=2, city="Almaty")

    def test_public_pages_and_anonymous_concert_protection(self):
        for name in ("index", "songs", "photos", "signup", "login"):
            self.assertEqual(self.client.get(reverse(name)).status_code, 200)
        self.assertRedirects(self.client.get(reverse("concerts")), reverse("login") + "?next=/concert/")
        self.assertIn(Concert, admin.site._registry)

    def test_signup_login_logout_and_duplicate(self):
        data = {"username": "listener", "password": "Test-only-pass123"}
        self.assertRedirects(self.client.post(reverse("signup"), data), reverse("index"))
        self.assertTrue(User.objects.get(username="listener").check_password(data["password"]))
        self.assertRedirects(self.client.get(reverse("logout")), reverse("login"))
        self.assertContains(self.client.post(reverse("signup"), data), "User already exists")
        self.assertNotIn("_auth_user_id", self.client.session)
        self.assertEqual(self.client.post(reverse("login"), {**data, "password": "wrong"}).status_code, 200)
        self.assertNotIn("_auth_user_id", self.client.session)
        self.assertRedirects(self.client.post(reverse("login"), data), reverse("index"))

    def test_attendance_changes_only_current_user(self):
        first = User.objects.create_user("first", password="Test-only-pass123")
        second = User.objects.create_user("second", password="Test-only-pass123")
        self.client.force_login(first)
        url = reverse("concert_attendee")
        self.assertEqual(self.client.get(url).status_code, 405)
        for status in ("Attending", "Not Attending"):
            self.assertRedirects(self.client.post(url, {"concert_id": self.concert.pk, "attendee_choice": status}), reverse("concerts"))
        self.assertEqual(ConcertAttending.objects.get(user=first).attending, "Not Attending")
        self.assertEqual(ConcertAttending.objects.count(), 1)
        self.assertEqual(self.client.post(url, {"concert_id": self.concert.pk, "attendee_choice": "bad"}).status_code, 400)
        self.assertEqual(self.client.get(reverse("concert_detail", args=[999])).status_code, 404)
        self.client.force_login(second)
        self.assertContains(self.client.get(reverse("concerts")), "Autumn Live")
        self.assertFalse(ConcertAttending.objects.filter(user=second).exists())

    @override_settings(SONGS_API_URL="http://songs.local/song", PICTURES_API_URL="http://pictures.local/picture")
    @patch("concert.views.requests.get")
    def test_microservice_integration_and_outage(self, get):
        response = Mock()
        response.json.return_value = [{"id": 7, "title": "API song", "lyrics": "Verse"}]
        get.return_value = response
        self.assertContains(self.client.get(reverse("songs")), "API song")
        get.assert_called_with("http://songs.local/song", timeout=5)
        response.json.return_value = [{"id": 7, "pic_url": "/static/images/img.jpeg", "event_city": "Almaty"}]
        self.assertContains(self.client.get(reverse("photos")), "Almaty")
        import requests
        get.side_effect = requests.ConnectionError("offline")
        self.assertContains(self.client.get(reverse("songs")), "temporarily unavailable", status_code=503)
